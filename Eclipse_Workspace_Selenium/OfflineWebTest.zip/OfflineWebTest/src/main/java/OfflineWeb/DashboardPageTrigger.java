package OfflineWeb;

public class DashboardPageTrigger {
	public static void main(String[] args) throws Exception {
		DashboardPageTestCase dashboard = new DashboardPageTestCase();
		dashboard.CheckingDashboardUrl();
	}
}
